
load TRAJ046.mat

t_step=2; % each time point is 0.5 fs, t_step is the time step size in # of elements, so 2 means 1 fs steps.
t_max = 740; % in fs (for extrapolation)
te=0:t_step/2:t_max; % extrap. time vector (fs)

xyz= TRAJ046.xyz(:,:,1:t_step:end); % read every t_step fs
t=TRAJ046.t(1:t_step:end);
t_ext=t(end)+(t_step/2):(t_step/2):t_max; % this extrapolates up to 640 fs, which is too much but we can truncate as needed

AtomName=TRAJ046.AtomName;
uName =unique(AtomName);
for n=1:numel(AtomName);Namen(n)=prod(single(AtomName{n}));end
for n=1:numel(uName);uNamen(n)=prod(single(uName{n}));end % convert from string to #

allpairs = nchoosek(1:numel(AtomName),2);
pl = Namen(allpairs);
[u_pairs, u_pairs_id, tot_pairs_id] = unique(pl, 'rows'); %

% pair label in string
u_pairs_str= strings(size(u_pairs));
for n=1:numel(uNamen)
    u_pairs_str(u_pairs==uNamen(n))=string(uName{n});
end

% get Rab the atom pair distance:
xyz_ab=(xyz(allpairs(:,2),:,:)-xyz(allpairs(:,1),:,:));
Rab =squeeze(vecnorm(permute(xyz_ab,[2 1 3])));

% find pair type ID
CC_id=find((tot_pairs_id==1)); % C-C
CO_id=find((tot_pairs_id==2)); % C-O
OO_id=find((tot_pairs_id==3)); % O-O
FeC_id=find((tot_pairs_id==4)); % Fe-C
FeO_id=find((tot_pairs_id==5)); % Fe-O

% which Fe-X pairs are "dissociating"  % validate the # using all traj
Cid=   sum(Rab(FeC_id,:)>3.5,2) ; % this is >x2 larger than the equil. dist (so it indicates dissoc.)
Oid=   sum(Rab(FeO_id,:)>3.5,2) ; % this is >x2 larger than the equil. dist (so it indicates dissoc.)
[~,COid]=max(sum([Oid, Cid],2)); % see where we have diss.

% get COM of CO in xyz
C = squeeze(xyz(allpairs(FeC_id(COid),2),:,:));
O = squeeze(xyz(allpairs(FeO_id(COid),2),:,:));
C_diss_atom_num=allpairs(FeC_id(COid),2);
O_diss_atom_num=allpairs(FeO_id(COid),2);

%diss_atoms_id    = [C_diss_atom_num O_diss_atom_num];
non_diss_atoms_id= find((1:numel(AtomName))~=C_diss_atom_num & (1:numel(AtomName))~=O_diss_atom_num);

% atomic masses
mC=12.011;             mO=15.9994;             mFe=55.845;
masses=[mFe  repmat(mC,1,5)   repmat(mO,1,5)];

% Calculate the center of mass of diss C and O
COM_CO        = (mC .* C + mO .* O) ./ (mC + mO);
COM_FeCO4     = squeeze(sum(bsxfun(@times,xyz(non_diss_atoms_id,:,:),permute(masses(non_diss_atoms_id),[2 1 3]))))./sum(masses(non_diss_atoms_id));
vector_COMs   = COM_FeCO4-COM_CO;
COMs          = vecnorm(vector_COMs);

% generalize to all non-diss atoms and not just Fe:
diss_CO_pair_id = (allpairs(:,1)==C_diss_atom_num) & (allpairs(:,2)==O_diss_atom_num);
nondiss_pair   = all(~(allpairs==C_diss_atom_num | allpairs==O_diss_atom_num),2);
all_diss_XCpairs  = (any((allpairs==C_diss_atom_num ),2)) & (~diss_CO_pair_id);
all_diss_XOpairs  = (any((allpairs==O_diss_atom_num ),2)) & (~diss_CO_pair_id);


id_XC=find(all_diss_XCpairs); % index of diss pairs X-C
id_XO=find(all_diss_XOpairs); % index of diss pairs X-O
id_Xn=find(nondiss_pair); % index of non-diss pairs
id_CO=find(diss_CO_pair_id);% index of the CO pair that is diss.

id_Xn_FeC=ismember(id_Xn,FeC_id);
id_Xn_FeO=ismember(id_Xn,FeO_id);
id_Xn_OO=ismember(id_Xn,OO_id);
id_Xn_CO=ismember(id_Xn,CO_id);
id_Xn_CC=ismember(id_Xn,CC_id);

% pair distances
XC=Rab(all_diss_XCpairs,:);
XO=Rab(all_diss_XOpairs,:);
Xn=Rab(nondiss_pair,:);
CO_diss=Rab(id_CO,:);

%% Extrap trajectories using DART:
% while this trajectory is 607 fs long, lets cut it at 350 to showcase the
% extrapolation method detailed.

% to extrapolate we first get an initial guess for t0, the diss time
t_stop=350; % traj truncation time (fs)
t_stop_id=find(t==t_stop);

clear dart_fit v_guess d_FeCO4_CO v12 t0
tt=t(1:t_stop_id);
Rab_gt=Rab;
Rab(:,t_stop_id+1:end)=[]; % delete Rab info after t_stop

xyz_in= xyz(:,:,1:t_stop_id); % Only use xyz up to t_stop
d_FeCO4_CO=COMs(1:t_stop_id);  % Only use the distance between the center of masses of FeCO4 and CO up to t_stop

r4_model = @(x,t) x(1) * (0.5 * (tanh((t - x(2))/x(4)) + 1) .* (t - x(2)))+x(3);
d12= @(x) (abs( r4_model(x,tt)- d_FeCO4_CO ));
v_guess=(d_FeCO4_CO(end)-d_FeCO4_CO(end-20))/(tt(end)-tt(end-20));
initp = [v_guess  ,   tt(end)/3, d_FeCO4_CO(1),         tt(end)/4];
lb=     [v_guess*0,     tt(1),   d_FeCO4_CO(1)*0.75,           0 ];
ub=     [v_guess*2,   tt(end),   d_FeCO4_CO(1)*1.25,    tt(end)/3];

options = optimoptions('lsqnonlin', ...
    'Display', 'off',...
    'Algorithm', 'levenberg-marquardt', ...  
    'MaxIterations', 1e6, ...                    
    'FunctionTolerance', 1e-16, ...               
    'StepTolerance', 1e-16, ...                  
    'SpecifyObjectiveGradient', false, ...      
    'UseParallel', false);
v12  = lsqnonlin(d12 ,initp,lb,ub,options ); % normal least squares
diss_atoms_id=find(~ismember(1:11,non_diss_atoms_id));
t0=v12(2); % the initial guess for t0, the diss time
[~, id_t0]=min(abs(t0-te));

% do the DART fit given the est diss time t0, on the full xyz positions and times
%  this will produce figure S3.
dart_fit_full_traj = DART(xyz,diss_atoms_id,t,t0,'true');

% do the DART fit given the est diss time t0, only on the first 350 fs xyz positions and times
dart_fit = DART(xyz_in,diss_atoms_id,tt,t0);

%%  extrapolate using DART results:

clear rn  azn eln omega_CO_est bb_range
rn=dart_fit.r;   % rn(diss_atoms_id(1),:)  is dC,  rn(diss_atoms_id(2),:)  is dO
azn=dart_fit.az;
eln=dart_fit.el;
omega_CO_est=dart_fit.omega_CO;

bb_range=  id_t0:numel(tt);
clear R4vt aznCO_model elnCO_model rCO_model rn_std rn_avg yr yel yaz elnCO_model aznCO_model

for np=1:numel(diss_atoms_id)
    clear yr yel yaz
    % set limits for extrap in r.
    rn_avg= mean(rn(diss_atoms_id(np),bb_range));
    rn_std= std(rn(diss_atoms_id(np),bb_range));
    lbb= rn_avg-5*rn_std;
    upp= rn_avg+5*rn_std;

    % extrap in r
    yr(1:numel(te))=0;
    yr(1:numel(tt))= rn(diss_atoms_id(np),:);
    yr(id_t0:numel(te)) = ExtrapolateSignalBurgBound(rn(diss_atoms_id(np),id_t0:t_stop_id),numel(te)-id_t0+1 ,lbb,upp);
    rCO_model(diss_atoms_id(np),:)=  yr;

    % el angle is assumed to be 0 for this case, extrap for small cor.
    eln_avg= mean(eln(diss_atoms_id(np),bb_range));
    eln_std= std(eln(diss_atoms_id(np),bb_range));
    lbb= eln_avg-5*eln_std;
    upp= eln_avg+5*eln_std;

    yel(1:numel(te))=0;
    yel(1:numel(tt))=eln(non_diss_atoms_id(np),:);
    yel(id_t0:numel(te))  = ExtrapolateSignalBurgBound(eln(non_diss_atoms_id(np),id_t0:t_stop_id),numel(te)-id_t0+1 ,lbb,upp);
    elnCO_model(diss_atoms_id(np),:)=yel;

    % extrap in az angle
    % for CO angle use omega_CO found and add linearly.
    yaz(1:numel(tt))= azn(diss_atoms_id(np),:);
    yaz((t_stop_id+1):numel(te))=azn(diss_atoms_id(np),t_stop_id)+ omega_CO_est.*(te((t_stop_id+1):end)-te(t_stop_id));
    aznCO_model(diss_atoms_id(np),:)=  yaz;
end

% extrapolate FeCO4 COM via model, extrap R4vt term
displacement = @(t) dart_fit.v * (0.5 * (1 + tanh(dart_fit.a * (t - dart_fit.t0)))) .* (t - dart_fit.t0);
R4vt= dart_fit.R0'+displacement(te).*dart_fit.R4';

clear x_ext y_ext z_ext
x_ext=squeeze(dart_fit.xyz_new(:,1,:));
y_ext=squeeze(dart_fit.xyz_new(:,2,:));
z_ext=squeeze(dart_fit.xyz_new(:,3,:));

for n=t_stop_id:numel(te)
    [x_ext(diss_atoms_id,n), y_ext(diss_atoms_id,n), z_ext(diss_atoms_id,n)] = sph2cart(...
        aznCO_model(diss_atoms_id,n) ,...
        elnCO_model(diss_atoms_id,n) ,...
        rCO_model(diss_atoms_id,n)    );
end

%% Combine results to get the extrapolated Rab
clear Rab_model  xyz_ab_model xyzr

% 1. extrap. the diss CO pair distance
Rab_model(id_CO,:)=rCO_model(diss_atoms_id(1),:)-rCO_model(diss_atoms_id(2),:);

% 2. extrap. the diss pairs...
xyzr = shiftdim(cat(3,x_ext', y_ext', z_ext'),1);
A4model=dart_fit.A4model;
A4params=dart_fit.A4Params;

clear A4C A4O A4Cext A4Oext delta_A4C delta_A4O
for n=1:9
    A4C(:,n)=vecnorm(squeeze(xyzr(diss_atoms_id(1),:,id_t0:t_stop_id))-  A4model(A4params(n,:),tt(id_t0:t_stop_id))'  );
    A4O(:,n)=vecnorm(squeeze(xyzr(diss_atoms_id(2),:,id_t0:t_stop_id))-  A4model(A4params(n,:),tt(id_t0:t_stop_id))' );

    A4Cext(:,n)=vecnorm(squeeze(xyzr(diss_atoms_id(1),:,id_t0:end))-  A4model(A4params(n,:),te(id_t0:end))'  );
    A4Oext(:,n)=vecnorm(squeeze(xyzr(diss_atoms_id(2),:,id_t0:end))-  A4model(A4params(n,:),te(id_t0:end))' );
end

delta_A4C=Rab(id_XC,id_t0:end)-A4C' ;
delta_A4O=Rab(id_XO,id_t0:end)-A4O';

for n=1:numel(id_XC)
    clear lbb upp dXC dXC_ext
    dXC= delta_A4C(n,:);
    if n>1
        lbb=  mean(dXC)-1*std(dXC);
        upp=  mean(dXC)+1*std(dXC);
    else
        lbb=  mean(dXC)-2*std(dXC);
        upp=  mean(dXC)+2*std(dXC);
    end

    dXC_ext= ExtrapolateSignalBurgBound(dXC,numel(te)-id_t0+1 , lbb,upp) +A4Cext(:,n)';
    Rab_model(id_XC(n),id_t0:numel(te))=ExtrapolateSignalBurgBound(dXC,numel(te)-id_t0+1 , lbb,upp)+A4Cext(:,n)';

    clear lbb upp dXO dXO_ext
    dXO= delta_A4O(n,:);
    if n>1
        lbb=   mean(dXO)-1*std(dXO);
        upp=    mean(dXO)+1*std(dXO);
    else
        lbb=   mean(dXO)-2*std(dXO);
        upp=    mean(dXO)+2*std(dXO);
    end

    dXO_ext=ExtrapolateSignalBurgBound(dXO,numel(te)-id_t0+1 , lbb,upp)+A4Oext(:,n)';
    Rab_model(id_XO(n),id_t0:numel(te))=ExtrapolateSignalBurgBound(dXO,numel(te)-id_t0+1 , lbb,upp)+A4Oext(:,n)';

end

% 3. Extrap. non_diss pairs
for n=1:numel(id_Xn)
    clear yr
    rxn_avg= mean(Rab(id_Xn(n) ,bb_range));
    rxn_std= std(Rab(id_Xn(n) ,bb_range));
    lbb= rxn_avg-4*rxn_std;
    upp= rxn_avg+4*rxn_std;

    yr(1:numel(te))=NaN;
    yr(1:numel(tt))= Rab(id_Xn(n),:);
    yr(id_t0:numel(te)) = ExtrapolateSignalBurgBound( Rab(id_Xn(n),id_t0:t_stop),numel(te)-id_t0+1 ,lbb,upp);

    Rab_model(id_Xn(n),:)=  yr;
end

%% Plot Fig S4 - Extrapolating atomic pair distances for a trajectory
Ang=char(197); lw=3;
annotationFontSize=20;
colo=get(gca,'ColorOrder');
colo(3,:)=[ 0.7561    0.1882    0.1882];
colo(8,:)=[ 0.8361    0.6246    0.1125];

% labels for the different atoms:
atomn=[0 1:5 1:5];
diss_atom_num= atomn(find(~ismember(1:11,non_diss_atoms_id)));

for n=1:numel(AtomName)
    if n>1
        strp{n}= [AtomName{n} '' num2str(atomn(n)) ''];
    else
        strp{n}= AtomName{n};
    end
end
 
 
figure('Name','SI - Figure S4','Position',[0 0 0.95*1500 0.95*1200])
tl=tiledlayout(3,5,"TileSpacing","tight","Padding","tight");

nexttile
tmid=round(t_stop_id/2);
% 3D structure in the middle of the trucated traj:
Amolecule3D(double( xyz(:,:,tmid)) ,AtomName  ); hold on
% add atom labels
for na=1:11
    if na>1 % for C, O atoms
        text(xyz(na,1,tmid)+1, xyz(na,2,tmid)-1.2, xyz(na,3,tmid)+0.4,[AtomName{na} num2str(atomn(na))] ,'FontSize',10,'FontWeight','bold','Color','w'); 
    else % for the Fe Atom
        text(xyz(na,1,tmid)+1, xyz(na,2,tmid)-1.2, xyz(na,3,tmid)+0.4,[AtomName{na}] ,'FontSize',10,'FontWeight','bold','Color','w' ); 
    end
end
el=15;
az=30;
camlight('left')
camlight(10,-50)
view(az,el)
camroll(180)
camzoom(1.6)

ax1=gca;
axlim=ax1.XLim;
aylim=ax1.YLim;
azlim=ax1.ZLim;

annotation('textbox','String','(a)','Position',ax1.Position-[-0.04 -0.02 0 0], ...
    'Vert','top','FitBoxToText','on','EdgeColor','none','FontSize',annotationFontSize)

%  diss. pairs plots
for np=1:9
    nexttile
    plot( t, XC(np,:),'-','Color',colo(8,:),'MarkerSize',5,'LineWidth',lw+1); hold on
    plot( t, XO(np,:),'-','Color',colo(1,:),'MarkerSize',5,'LineWidth',lw+1); 
    hold on
    plot(te(te<=t_stop & te>=dart_fit.t0),Rab_model( id_XC(np), te<=t_stop & te>= dart_fit.t0),'-','Color',colo(3,:),'LineWidth',lw)
    plot(te(te<=t_stop & te>= dart_fit.t0),Rab_model( id_XO(np), te<=t_stop & te>= dart_fit.t0),'-','Color',colo(4,:),'LineWidth',lw)

    plot(te(te>=t_stop), Rab_model( id_XC(np), te>=t_stop),':','Color',colo(3,:),'LineWidth',lw)
    plot(te(te>=t_stop), Rab_model( id_XO(np), te>=t_stop),':','Color',colo(4,:),'LineWidth',lw)

    text(20,12,['(b' num2str(np) ')'],'FontSize',annotationFontSize)
    lgnd=legend([strp{ non_diss_atoms_id(np)} '-C' num2str(diss_atom_num(1)) ''],[strp{ non_diss_atoms_id(np)} '-O' num2str(diss_atom_num(2)) ''],...
        'fit', 'fit' ,'extrap.', 'extrap.', 'Location','southeast');
    lgnd.ItemTokenSize = [10,8];
    lgnd.NumColumns = 3;
    lgnd.FontSize=12;
    xlim([0 640])
    ylim([0.5 13]);
    ylabel(['R (' Ang ')'])
    xlabel('Delay (fs)');
    set(gca,'FontSize',12)
end

% non-diss. pairs plots
for np0=1:5
    nexttile
    clear temp temp2
    switch np0
        case 1
            temp= Xn( id_Xn_FeC,:);
            temp2= Rab_model( id_Xn( id_Xn_FeC),:);
            strtitle='Fe-C';
        case 2
            temp= Xn( id_Xn_FeO,:);
            temp2= Rab_model( id_Xn( id_Xn_FeO),:);
            strtitle='Fe-O';
        case 3
            temp= Xn( id_Xn_CO,:);
            temp2= Rab_model( id_Xn( id_Xn_CO),:);
            strtitle='C-O';
        case 4
            temp= Xn( id_Xn_CC,:);
            temp2=  Rab_model( id_Xn( id_Xn_CC),:);
            strtitle='C-C';
        case 5
            temp= Xn( id_Xn_OO,:);
            temp2= Rab_model( id_Xn( id_Xn_OO),:);
            strtitle='O-O';
    end

    plot( t,temp(1,:),'Color',colo(1,:),'LineWidth',2);hold on
    plot(te(t_stop_id:end),temp2(1,t_stop_id:end),':','Color',colo(2,:),'LineWidth',2)

    plot( t,temp,'Color',colo(1,:),'LineWidth',2);hold on
    plot(te(t_stop_id:end),temp2(:,t_stop_id:end),':','Color',colo(2,:),'LineWidth',2)

    text(20,12,['(c' num2str(np0) ')'],'FontSize',annotationFontSize)

    lgnd=legend([strtitle ' (non-diss.)'],'extrap.' , 'Location','northeast');
    lgnd.ItemTokenSize = [10,8];
    lgnd.NumColumns = 1;
    lgnd.FontSize=12;

    ylim([0.5 13 ]);
    xlim([0 640]);
    ylabel(['R (' Ang ')'])
    xlabel('Delay (fs)');
    set(gca,'FontSize',12)
end