
load trajset
Ang=char(197);
fontsize=16;
annotationFontSize=24;

figure
contour_data = contour(trajset.pair_crossing.t_grid,...
    trajset.pair_crossing.R_grid,...
    trajset.pair_crossing.RTW,...
    trajset.pair_crossing.cont_range);

ylim([0.7 10])
colorbar
ylabel(['R (' Ang ')'])
xlabel(['Delay (fs)'])
set(gca,'FontSize',fontsize)

GT=trajset.GT; % extrapolated traj that had a termination time greater than 210 fs and a period of at least 120 fs from dissociation to termination
t_diss=trajset.t_diss;
v_diss_com=trajset.v_diss_com;

goodind= GT & ...
    (v_diss_com>1  & t_diss>0) ; % for dissociation and rotation pick trajectories that did dissociate in the time window simulated.


figure('Position',[100 100 1500 450])
tiledlayout(1,3)
nexttile
cmr=-2:12:140;
crr=1.5:2:25;
cm_inv = @(thz) thz  /0.0299792458;
% Create the first axes and plot
hdiss=histogram( v_diss_com(goodind) , crr,"Normalization","pdf");%,'DisplayStyle','tile','ShowEmptyBins','off')
hdiss.FaceColor=[0.5 0.5 0.5];


hold on
V1= v_diss_com(goodind);
distV1 = fitdist(V1(:), 'gev');%'gev' 'Poisson' 'Binomial
ci1 = paramci(distV1);
x_values1 = 3:0.1:26; % Edges for V1
pdfV1 = pdf(distV1, x_values1);
v_diss_traj_avg=distV1.mu;
v_diss_traj_sig=distV1.sigma;%diff(ci1(:,3))/2;
plot( x_values1, pdfV1, '--r','LineWidth',2);

hold on
errorbar(v_diss_traj_avg,max(pdfV1)/2,v_diss_traj_sig,1.5*v_diss_traj_sig,'horizontal','ro','MarkerSize',9,'LineWidth',2,'CapSize',18)
xlabel(['Dissociation velocity (' Ang '/ps)'])
ylabel(['Probability'])
set(gca,'FontSize',fontsize)
legend( '','Probability dist. fit')
ax21=gca;
set(ax21,'TickLength',[0.02 0.02]);
annotation('textbox','String',"(a)",'Position',ax21.Position-[-0.0  0 0 0], ...
    'Vert','top','FitBoxToText','on','EdgeColor','none','FontSize',annotationFontSize, 'Color', 'k')

% % % % % % % % %
nexttile
rot_vel= cm_inv(1e3./(trajset.TCOrot(goodind )) )' ;
hrot=histogram(rot_vel, cmr,"Normalization","pdf");
hrot.FaceColor=[0.5 0.5 0.5];
V2= rot_vel;
distV2 = fitdist(V2, 'gev');
ci2 = paramci(distV2);
x_values2 =  0:2:150;
pdfV2 = pdf(distV2, x_values2);
hold on
plot( x_values2, pdfV2, '--r','LineWidth',2);
rot_freq_traj_avg=distV2.mu;
rot_freq_traj_std=distV2.sigma; ;
errorbar(rot_freq_traj_avg,max(pdfV2)/2,rot_freq_traj_std,rot_freq_traj_std*1.5,'horizontal','ro','MarkerSize',9,'LineWidth',2,'CapSize',18)

legend( '','Probability dist. fit')
xlabel('CO Rotation frequency (cm^{-1})' )
ylabel(['Probability'])
set(gca,'FontSize',fontsize)
set(gca,'TickLength',[0.02 0.02]);
ax22=gca;

annotation('textbox','String',"(b)",'Position',ax22.Position-[-0.0  0 0 0], ...
    'Vert','top','FitBoxToText','on','EdgeColor','none','FontSize',annotationFontSize, 'Color', 'k')


% % % % % % % % %
nexttile

h3=histogram2(  rot_vel', v_diss_com(goodind) ,...
    cmr,  crr ,'DisplayStyle','tile','ShowEmptyBins','on','Normalization','probability'); hold off

binCounts = h3.Values; % The matrix of bin counts
edgesX = h3.XBinEdges; % X edges
edgesY = h3.YBinEdges; % Y edges

% Calculate bin centers for interpolation
binCentersX = edgesX(1:end-1) + diff(edgesX)/2;
binCentersY = edgesY(1:end-1) + diff(edgesY)/2;

% Create a grid for the bin centers
[X, Y] = meshgrid(binCentersX, binCentersY);

% Extend the grid for pcolor
[Xq, Yq] = meshgrid(linspace(min(binCentersX), max(binCentersX), length(binCentersX)), ...
    linspace(min(binCentersY), max(binCentersY), length(binCentersY)));

xlabel('CO Rotation frequency (cm^{-1})' )
ylabel(['Dissociation velocity (' Ang '/ps)'])


set(gca,'FontSize',fontsize)

cb4=colorbar;
colorTitleHandle = get(cb4,'Title');
titleString = 'Prob.';
set(colorTitleHandle ,'String',titleString);

ax33=gca;
annotation('textbox','String',"(c)",'Position',ax33.Position-[-0.0  0 0 0], ...
    'Vert','top','FitBoxToText','on','EdgeColor','none','FontSize',annotationFontSize, 'Color', 'w')