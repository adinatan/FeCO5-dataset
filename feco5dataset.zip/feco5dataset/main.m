% Main script for data files included

clear all
close all
projectDir = pwd;

% Add the subfolders 'data' and 'utils' to the MATLAB path
addpath(fullfile(projectDir, 'data'));
addpath(fullfile(projectDir, 'utils'));

% Run scripts  
scattering_and_pd_script;  % loads and plots main scattering and pair-distance data
traj_all_pairs_plots;      % loads and plots averages of all trajectory data
trajset_script;            % loads and plots histograms for trajectory parameters
traj_extrap_demo;          % demonstrates trajectory extrapolation using the DART method