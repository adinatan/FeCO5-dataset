Data files structures:

--------------------------------------------------------------------------------
exptdata.mat (struct)
--------------------------------------------------------------------------------
├─ t ......................... [1×70 double]
│                              (pump-probe time delay vector, in ps)
├─ q ......................... [1×1225 double]
│                              (q vector, in A^-1)
├─ R ......................... [260×1 double]
│                              (Real space vector, in A)
├─ S0 ........................ [1225×70 double]
│                              (Experimental Isotropic difference scattering 
│                               array, q × t)
├─ S2 ........................ [1225×70 double]
│                              (Experimental Anisotropic difference scattering
│                               array, q × t)
└─ PD0 ....................... [260×70 double]
                               (Experimental Pair density difference array,  
                                R × t, obtained from inverting S0)

Note that the vectors t and q are not uniformly spaced.

--------------------------------------------------------------------------------
simdata.mat (struct)
--------------------------------------------------------------------------------
├─ t ......................... [1×741 double]
│                              (time vector, in fs)
├─ q ......................... [1×73 double]
│                              (q vector, in A^-1)
├─ R ......................... [1×520 double]
│                              (Real space vector, in A)
├─ S0traj .................... [73×741 double]
│                              (Sim. Isotropic scattering array, averaged 
│                               over all trajectories)
├─ S2atraj ................... [73×741 double]
│                              (Sim. Anisotropic scattering array, assuming 
│                               axial dipole direction)
├─ S2etraj ................... [73×741 double]
│                              (Sim. Anisotropic scattering array, assuming 
│                               equatorial dipole direction)
└─ PD0traj ................... [520×741 double]
                               (Sim. Pair density array, R × t, from inverting 
                                S0traj)


--------------------------------------------------------------------------------
sim_all_traj_avg.mat (struct)
--------------------------------------------------------------------------------
├─ t ......................... [1×741 double]
│                              (time vector, in fs)
├─ Rab_grid .................. [1×120 double]
│                              (Real space vector, in A)
├─ u_pairs_str ............... [5×2 string]
│                              (labels of atom pairs, e.g. ["C" "C"])
└─ pairs ..................... [120×741×5 double]
                               (histogram of atom pairs' charge density, in e^2, 
                                as a function of space, time, and pair type)


--------------------------------------------------------------------------------
Trajset.mat (struct)
--------------------------------------------------------------------------------
├─ t_diss .................... [1×116 double]
│                              (estimated dissociation time, in fs)
├─ v_diss_com ................ [1×116 double]
│                              (estimated dissociation velocity, in A/fs)
├─ TCOrot .................... [1×116 double]
│                              (estimated rotation period of the dissociating CO, 
│                               in fs)
├─ t_cut ..................... [1×116 double]
│                              (termination times of each trajectory, in fs)
├─ GT ........................ [1×116 logical]
│                              (flag for trajectories selected for further 
│                               extrapolation based on t_diss and t_cut)
└─ pair_crossing (struct)
   ├─ RTW .................... [150×30 double]
   │                           (histogram of positions & times where pair 
   │                            distances crossed one another (< 0.1 Å), 
   │                            weighted by pair density)
   ├─ t_grid ................. [1×30 double]
   │                           (time grid for the RTW histogram)
   ├─ R_grid ................. [1×150 double]
   │                           (real-space grid for the RTW histogram)
   └─ cont_range ............. [20 30 40 50 60 70]
                               (contour line ranges for RTW histogram, in e^2)


--------------------------------------------------------------------------------
nma.mat (struct)
--------------------------------------------------------------------------------
├─ Rabi ...................... [36×341×3×5 double]
│                              (histogram of pair distances per pair, 
│                               time, mode type, and mode #)
├─ tauu ...................... [1×341 double]
│                              (time vector, in fs)
├─ pairstr ................... {["C-C"] ["Fe-C"] ["C-O"] ["Fe-O"] ["O-O"]}
│                              (labels for the types of pairs)
├─ fftnma .................... [2048×3×5 double]
│                              (Fourier transform of the different modes)
├─ freq_vec .................. [1×2048 double]
│                              (Fourier frequency vector, in THz)
├─ u_pairs ................... [5×2 string]
│                              (pair types, redundant with pairstr)
├─ pairs_id .................. [36×1 double]
│                              (pair # ID for the Rabi array)
└─ D {3×5 cell}                (cell array of structs, mode type x mode #, each with fields:)
   ├─ atomname ............... [9×20 double]
   ├─ xyz .................... [9×3×20 double]
   │                           (positions, in Å)
   ├─ dis .................... [9×3×20 double]
   │                           (displacements, in Å)
   ├─ mod .................... 'FeCO4_CS_singlet_opt_freq.out.v006'
   │                           (original file name used)
   ├─ freq ................... 42.0200
   │                           (mode frequency, in cm^-1)
   ├─ tau .................... [1×20 double]
   │                           (time vector, in fs)
   └─ title .................. 'CS'
                               (mode type)


--------------------------------------------------------------------------------
TRAJ046.mat (struct)
--------------------------------------------------------------------------------
├─ AtomName .................. {'Fe' 'C' 'C' 'C' 'C' 'C' 'O' 'O' 'O' 'O' 'O'}
├─ xyz ....................... [11×3×1216 double]
│                              (positions, in Å)
└─ t ......................... [1×1216 double]
                               (time vector, in fs)
--------------------------------------------------------------------------------