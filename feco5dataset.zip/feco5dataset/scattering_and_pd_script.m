
load exptdata
R=exptdata.R;
t=exptdata.t;
q=exptdata.q;
S0=exptdata.S0;
S2=exptdata.S2;
PD0=exptdata.PD0;
EFest=0.08; % estimated excitation fraction

load simdata

figure("Name"," SI - Fig S1 - Expt. vs Sim. Scattering data")
Ang=char(197); % for the Angstrom symbol
 
nexttile
[Xt, Yq] = meshgrid(t,q);
surf(Xt, Yq, S0, 'EdgeColor', 'none');
view(2);
set(gca, 'XTickMode','auto','YTickMode','auto', 'Layer', 'top');
grid off
box on 

 
clim([-75 30])
xlim([-.1  1.2 ])
ylim([0 4.35])
 
set(gca,'Ydir','normal');
ylabel(['Q (' Ang '^{-1})']);
xlabel('Delay (ps)');
colormap(gca,bluewhitered(256));
title('Expt. \DeltaS_0(Q,\tau)')
cb0= colorbar;
cb0.LineWidth=1;
cb0.FontSize=10;
colorTitleHandle = get(cb0,'Title');
titleString = 'e^2';
set(colorTitleHandle ,'String',titleString);

nexttile
surf(Xt, Yq, S2, 'EdgeColor', 'none');
view(2);    
set(gca, 'XTickMode','auto','YTickMode','auto', 'Layer', 'top');
grid off
box on 
clim([-0.5 0.25 ])
xlim([-.1  1.2 ])
ylim([0 4.35])


set(gca,'Ydir','normal');
ylabel(['Q (' Ang '^{-1})']);
xlabel('Delay (ps)');
colormap(gca,bluewhitered(256));
title('Expt. \DeltaS_2(Q,\tau)')
cb0= colorbar;
cb0.LineWidth=1;
cb0.FontSize=10;
colorTitleHandle = get(cb0,'Title');
titleString = 'e^2';
set(colorTitleHandle ,'String',titleString);


dS0traj=simdata.S0traj-simdata.S0traj(:,1);

nexttile
imagesc(simdata.t*1e-3 ,simdata.q, EFest*dS0traj);%  ,"EdgeColor","none")

clim([-75 30])
xlim([-.1  1.2 ])
ylim([0 4.35])
set(gca,'Ydir','normal');
ylabel(['Q (' Ang '^{-1})']);
xlabel('Delay (ps)');
colormap(gca,bluewhitered(256));
title('Sim. \DeltaS_0(Q,\tau)')
cb0= colorbar;
cb0.LineWidth=1;
cb0.FontSize=10;
colorTitleHandle = get(cb0,'Title');
titleString = 'e^2';
set(colorTitleHandle ,'String',titleString);


nexttile
FF=0.72e-2*EFest; % fudge factor, as we dont know the dipole strengh, so we compare to the experiment
dS2traj=simdata.S2atraj-simdata.S2atraj(:,1);

imagesc(simdata.t(1:635)*1e-3,simdata.q,FF*dS2traj(:,1:635));% 
caxis([-0.5 0.25 ])
xlim([-.1  1.2 ])
ylim([0 4.35])

set(gca,'Ydir','normal');
ylabel(['Q (' Ang '^{-1})']);
xlabel('Delay (ps)');
colormap(gca,bluewhitered(256));
title('Sim. \DeltaS_2(Q,\tau)')
cb0= colorbar;
cb0.LineWidth=1;
cb0.FontSize=10;
colorTitleHandle = get(cb0,'Title');
titleString = ['e^2'];
set(colorTitleHandle ,'String',titleString);
 
 


%% PD(R,t)
%resample to uniform time bins at dt=25 fs
dt=25;
[~, id] = min(abs(t(t<0)*1e3 - round(t(t<0)*1e3/dt)*dt));
[pd0,t_fs] = resample(PD0(:,id:end)',t(id:end)*1e3 ,1./dt);
pd0=pd0';


figure("Name","Expt. Pair density difference")
nexttile
imagesc(t_fs,R,pd0)
caxis([-8*mad(pd0(:)) 8*mad(pd0(:)) ]);
set(gca,'Ydir','normal');
ylim([0.7 12])
xlim([-100 1200])
ylabel(['R (' Ang ')']);
xlabel('Delay (fs)');
colormap(gca,bluewhitered(256));
title('Expt. PD_0(R,\tau)')

% sim pd0:
dttraj=mean(diff(simdata.t));
% pad zero from the left:
neg_time_add=-dttraj*20:dttraj:-dttraj;
ttraj  = [neg_time_add simdata.t];
pd0traj= [zeros(numel(simdata.R),numel(neg_time_add)) , simdata.PD0traj];
 
estIRF = 58;
tau = -50*dttraj : dttraj : 50*dttraj;
filttrajtau = exp(-tau.^2 ./ (2*(estIRF/2.355)^2));

for nr = 1:numel(simdata.R)
    pd0_traj(nr,:) = conv(pd0traj(nr,:), filttrajtau,'same' );
end
 
 
nexttile
imagesc(simdata.t,simdata.R, pd0_traj)
caxis([-8*mad(pd0(:)) 8*mad(pd0(:)) ]);
set(gca,'Ydir','normal');
ylim([0.7 12])
xlim([-100 1200])
ylabel(['R (' Ang ')']);
xlabel('Delay (fs)');
colormap(gca,bluewhitered(256));
title('Sim PD_0(R,\tau)')