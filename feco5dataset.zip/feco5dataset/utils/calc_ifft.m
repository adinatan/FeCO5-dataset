function [freq_vec,fft_vec]=calc_ifft(vec,dt)
% calculate the FFT frequency vector:
%
% Inputs:
%   vec -  a 1-D time vector 
%   dt - the time interval of this vector in the units of choice
%
% Outputs:
%   fft_vec - the fft of vec
%   freq_vec - the frequncy vector 1/the units of the time vector
%
% --------------------------------------------------------------------
%
%   Adi Natan (natan@stanford.edu)
%
% --------------------------------------------------------------------

N=numel(vec);
df=1/(N*dt);		% the frequency resolution (df=1/max_T)

% use a window function to reduce artifacts \ spectral leakage in the FFT
switch 'hann'
    case 'hann'
        f=window(@hann,N)';
    case 'hamming'
        f=window(@hamming,N)';
    case 'kaiser'
        f=window(@kaiser,N,7)';       
    case 'none'
        f=1;
end

if mod(N,2)==0
    f_vector= df*((1:N)-1-N/2);   	% frequency vector for EVEN length vectors: f =[-f_max,-f_max+df,...,0,...,f_max-df]
else
    f_vector= df*((1:N)-0.5-N/2);   % frequency vector for ODD length vectors f =[-f_max,-f_max+fw,...,0,...,f_max]
end
freq_vec=f_vector;
fft_vec=fftshift(ifft(vec(:).*f(:)));

% %plots if needed
% subplot(2,1,1);
% plot(freq_vec,abs(fft_vec));
% xlabel('frequency');
% ylabel('FFT mag.')
% grid on
% subplot(2,1,2);
% plot(freq_vec,(angle(fft_vec))/pi);
% xlabel('frequency');
% ylabel('phase (Rad/Pi)')