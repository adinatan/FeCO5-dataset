function xyz_all_new   = dart_transform(xyz_all,diss_atoms_id,id_t0)
% --------------------------------------------------------------------
% Helper function to be used with DART.m
%
% Inputs:
%    xyz_all -  a 3d array of number of atoms x 3 x  times points 
%    diss_atoms_id - the index from the xyz of the CO atoms that diss.
%    id_t0 - the index for the time vector element closest to the estimated dissociation time

% Outputs:
%    xyz_new: xyz in the new DART frame

% --------------------------------------------------------------------
%   Ver 1.02 (2024-07-01)
%   Adi Natan (natan@stanford.edu)
% --------------------------------------------------------------------

xyz=xyz_all(:,:,id_t0);
non_diss_atoms_id= find((1:size(xyz,1))~=diss_atoms_id(1) & (1:size(xyz,1))~=diss_atoms_id(2));
mC=12.011;             mO=15.9994;             mFe=55.845;

% Calculate center of mass
C = xyz(diss_atoms_id(1), :);
O = xyz(diss_atoms_id(2), :);
center_of_mass = (mC * C + mO * O) / (mC + mO);

% Translate all coordinates to the new origin
xyz_new = xyz - center_of_mass;
% Rotate coordinates to align id_diss rows on the x-y plane
% Compute angles required to rotate row 4 to the x-axis
theta = atan2(C(3), C(2));
psi   = atan2(sqrt(C(2)^2 + C(3)^2), C(1));

%  rotation matrices
Rz = [cos(theta) -sin(theta) 0; sin(theta) cos(theta) 0; 0 0 1];
Rx = [1 0 0; 0 cos(psi) -sin(psi); 0 sin(psi) cos(psi)];

% Apply rotations
xyz_new = (Rz * Rx * xyz_new')';

% Coordinates of rows id_diss in the translated system
newC = xyz_new(diss_atoms_id(1), :);
newO = xyz_new(diss_atoms_id(2), :);

% the angle to rotate newC to lie along the x-axis
theta = -atan2(newC(2), newC(1));  % Rotation around z-axis

% rotation around Z to align newC with the x-axis
Rz2 = [cos(theta) -sin(theta) 0; sin(theta) cos(theta) 0; 0 0 1];
xyz_new = (Rz2 * xyz_new')';

% adjust newO to lie on the x-y plane, need to ensure newO is rotated in x-y plane properly
phi = -atan2(newO(3), sqrt(newO(1)^2 + newO(2)^2));  % Rotation around y-axis
Ry = [cos(phi) 0 sin(phi); 0 1 0; -sin(phi) 0 cos(phi)];
xyz_new = (Ry * xyz_new')';

%  apply this transfrom to the moving center of mass of the CO, COM_CO:
C             = (xyz_all(diss_atoms_id(1),:,:));
O             = (xyz_all(diss_atoms_id(2),:,:));
COM_CO        = (mC .* C + mO .* O) ./ (mC + mO);

xyz_all_new=zeros(size(xyz_all));
for n=1:size(xyz_all,3)
    xyz_all_new(:,:,n) = (Ry * (Rz2 *  (Rz * Rx * (xyz_all(:,:,n) - COM_CO(:,:,n))')))';
end

% Fit a plane to the points specified by id_diss and tau_range
tau_range=id_t0:size(xyz_all,3);
points = xyz_all_new(diss_atoms_id, :, tau_range);
points = permute(points, [1 3 2]);  % to make it (number of id_diss) x (length of tau_range) x 3
points = reshape(points, [], 3);  %  reshape to (number of id_diss * length of tau_range) x 3

% Perform SVD on the points
[~, ~, V] = svd(bsxfun(@minus, points, mean(points, 1)), 'econ');
normal = V(:, 3);  % The third column of V is the normal to the plane

% Compute rotation matrix to align this normal with the Z-axis
z_axis = [0; 0; 1];
Axis = cross(normal, z_axis);
if norm(Axis) ~= 0
    Axis = Axis / norm(Axis);
    Angle = acos(dot(normal, z_axis));
    K = [0, -Axis(3), Axis(2); Axis(3), 0, -Axis(1); -Axis(2), Axis(1), 0];
    R_align = eye(3) + sin(Angle) * K + (1 - cos(Angle)) * K^2;
else
    R_align = eye(3);  % No rotation needed if normal is parallel to z_axis
end

for n=1:size(xyz_all,3)
    xyz_all_new(:,:,n) = (R_align * xyz_all_new(:,:,n)')';
end
end
% % Visualization of the fitted plane and points
% figure;
% scatter3(points(:,1), points(:,2), points(:,3), 'filled');
% hold on;
%
% % Define a grid for the plane display
% [x_grid, y_grid] = meshgrid(linspace(min(points(:,1)), max(points(:,1)), 10), ...
%                             linspace(min(points(:,2)), max(points(:,2)), 10));
% z_grid = (-normal(1) * (x_grid - mean(points(:,1))) - normal(2) * (y_grid - mean(points(:,2)))) / normal(3) + mean(points(:,3));
% surf(x_grid, y_grid, z_grid, 'FaceAlpha', 0.5, 'EdgeColor', 'none');