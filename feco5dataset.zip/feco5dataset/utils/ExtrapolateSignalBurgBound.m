function y = ExtrapolateSignalBurgBound(x, P, y1, y2)
% --------------------------------------------------------------------
% Extrapolate Signal using Burg's AR method with bounds
%
% Inputs:
%    x -  input vector 
%    P -  Number of samples in the extrapolated time series
%    y1,y2 - lower and upper bounds
%
% Outputs:
%    y -  extrapolated vector (the output contains the input and the extrapolation)
%
% example:
% x = @(t) 6*sin(t/3.6+.2)+3*sin(t/1.2-.1)+2*sin(t/32.7+.5); % a "measured" signal form
% t1=1:50; % "truncated" time of measurement
% P=100; % time element to extrapolate to
% t=1:P;
% lb=mean(x(t1))-3*std(x(t1)); ub=mean(x(t1))+3*std(x(t1));
% y = ExtrapolateSignalBurgBound(x(t1), P,lb,ub );
% plot(t, x(t),'b', t(numel(t1)+1:end) , y(numel(t1)+1:end) ,':r','LineWidth',2); hold on
% xline(t1(end),'k-');
% legend('actual signal', 'extrapolated signal', 'start of extrapolation','Location','northoutside');

% --------------------------------------------------------------------
%   Ver 1.02 (2024-07-01)
%   Adi Natan (natan@stanford.edu)
% --------------------------------------------------------------------

M = numel(x);
p =  M-1;  
valid = false;

% Previously we tested many pairs and found that min p ~< 20 often works based on BIC.
% for p_i = 1:1:M-1
%     % Estimate AR coefficients using Burg's method
%     [a, e] = arburg(x, p_i);
%
%     % Calculate the log-likelihood for the model
%     % Log-likelihood for Gaussian errors is given by:
%     LL = -(M/2)*(1 + log(2*pi) + log(e/(M-p_i)));
%
%     % Calculate AIC and BIC using built-in function
%     [~, bic] = aicbic(LL, p_i+1, M);  % +1 because we include the variance parameter
%
%     BIC(p_i) = bic;
% end
% figure; plot(BIC)

% Find the optimal model order with the minimum BIC
%[~, p_opt] = min(BIC);
%figure; plot(BIC); hold on; xline(p_opt)


while ~valid && p > 1
    % Use the trailing end part of the input
    x_trail = x(end-p+1:end);
    a = arburg(x_trail, p-1);
    N = numel(a) - 1;
    y = NaN(1, P);

    % fill in the known part of the time series
    y(1:M) = x;
    for ii = (M+1):P
        y(ii) = -sum(a(2:end) .* y((ii-1):-1:(ii-N)));
    end
    % Check if all values are within bounds
    if all(y >= y1 & y <= y2)
        valid = true;  % If valid, exit loop
    else
        p = p-round(p/2);   % Decrease p to try a simpler model
    end
end
if ~valid
    y((M+1):P)=y(M);
end
end