function out = DART(xyz,diss_atoms_id,tt,t0,plotflag)
% --------------------------------------------------------------------
% Inputs:
%    xyz -  a 3d array of number of atoms x 3 x  times points 
%    diss_atoms_id - the index from the xyz of the CO atoms that diss.
%    tt - time vecotr
%    t0 - the guess for the dissociation time

% Outputs:
% * R0: the estimated initial displacment position of sigma4   
% * t0: est. diss. time
% * R4: direction of sigma4 in the DART frame
% * v: est. diss. velocity  
% * a: est time to "accelerate" to v
% * xyz_new: xyz in the new DART frame
% * [r, el, az]: same like  xyz_new but in spherical coord.
% * omega_CO: est. rotation freq of the diss CO
% * A4Params: [9×3 double]
% * A4model: [function_handle]

% --------------------------------------------------------------------
%   Ver 1.02 (2024-07-01)
%   Adi Natan (natan@stanford.edu)
% --------------------------------------------------------------------

if nargin<5
    plotflag=0;
end

%% prep steps
mC=12.011; mO=15.9994; mFe=55.845;
masses=[mFe  repmat(mC,1,5)   repmat(mO,1,5)];

non_diss_atoms_id= find(~ismember(1:size(xyz,1),diss_atoms_id));

% original traj. coordinates:
C             = (xyz(diss_atoms_id(1),:,:));
O             = (xyz(diss_atoms_id(2),:,:));
COM_CO        = (mC .* C + mO .* O) ./ (mC + mO);
COM_FeCO4     = (sum(bsxfun(@times,xyz(non_diss_atoms_id,:,:),permute(masses(non_diss_atoms_id),[2 1 3]))))./sum(masses(non_diss_atoms_id));

vector_COM_C  = squeeze(COM_CO - C);
vector_COMs   = squeeze(COM_FeCO4-COM_CO);
d_FeCO4_CO    = vecnorm(vector_COMs);

[~, id_t0]=min(abs(t0-tt));

%% Transfrom and get fit params:
% Do the transfrom:
xyz_new = dart_transform(xyz,diss_atoms_id,id_t0);
% go to Polar coord. to estimate omega_CO:
for n=1:numel(tt)
    [az(:,n), el(:,n), r(:,n)] = cart2sph(xyz_new(:,1,n), xyz_new(:,2,n), xyz_new(:,3,n));
end

if numel(tt)-id_t0<200
    omege_CO_range=id_t0:numel(tt);
else
    omege_CO_range=id_t0+100:numel(tt);
end

omega_est=@(x)  median(filtfilt(fir1(min([25 floor(0.333*numel(x(floor(end/2):end)))]), eps), 1, x(floor(end/2):end)));
omega_CO=omega_est(  ( diff(unwrap(az(diss_atoms_id(1),omege_CO_range)))));

% model R4:
COM_FeCO4_new = (squeeze(sum(bsxfun(@times,xyz_new(non_diss_atoms_id,:,:),permute(masses(non_diss_atoms_id),[2 1 3]))))./sum(masses(non_diss_atoms_id)))';
R4direction = find_direction_vector(COM_FeCO4_new)';
v_guess=(d_FeCO4_CO(end)-d_FeCO4_CO(id_t0))/(tt(end)-tt(id_t0));
a_est=50; % half the vibrartion of Fe-C in fs
if id_t0>1
    R4_init=trimmean(COM_FeCO4_new(1:(id_t0),:),37);
else
    R4_init= COM_FeCO4_new( id_t0 ,:) ;
end

initialGuess=[R4_init,t0,R4direction,v_guess,a_est];
points=COM_FeCO4_new(id_t0:end,:);
R4model= @(x,t) (x(1:3)+ x(8) * (0.5 * (1 + tanh(x(9) * (t(:) - x(4))))) .* (t(:) - x(4) )*( x(5:7)./  norm(x(5:7))) );
trajerror = @(x) sum((tt(id_t0:end).^0.5).*vecnorm(abs(points - R4model(x,tt(id_t0:end )) )'));

options = optimoptions('fminunc', ...
    'Display', 'off',...
    'Algorithm', 'quasi-newton', ... % Set optimization algorithm
    'MaxIterations', 1e6, ...      % Maximum number of iterations
    'OptimalityTolerance', 1e-16, ... % Tolerance for the optimality
    'StepTolerance', 1e-16);         % Tolerance for the step size

[R4Params, ~] = fminunc(trajerror, initialGuess, options);
fittedR4Trajectory = R4model(R4Params,tt);

%% model atom A traj as a displaced FeCO4 COM, pointing to the same direction:
% Apply the direction found in R4 to all atoms A, and find the optimal
% displacement given the parameters of R4 found

% model A4:
A4model= @(x,t) x(1:3)+ R4Params(8) * (0.5 * (1 + tanh(R4Params(9) * (t(:) - R4Params(4))))) .* (t(:) - R4Params(4) )*( R4Params(5:7)./  norm(R4Params(5:7))) ;

for n=1:numel(non_diss_atoms_id)
    clear points
    points=squeeze(xyz_new(non_diss_atoms_id(n),:,id_t0:end))';
    [linePoints, Aguess(:,n), A0guess(:,n),vAguess(n)] = fit3DLine(points);
    initiaAlGuess= [R4Params(5:7)./norm(R4Params(5:7))]  - [Aguess(:,n)./norm(Aguess(:,n))]';
    trajAerror = @(x) sum((tt(id_t0:end).^0.5).*vecnorm(abs(points - A4model(x,tt(id_t0:end)) )'));
    fittedATrajectory(n,:,:)=linePoints';
    [A4Params(n,:), ~] = fminunc(trajAerror, initiaAlGuess, options);
end

out.R0=R4Params(1:3);
out.t0=R4Params(4);
out.R4=R4Params(5:7);
out.v=R4Params(8);
out.a=R4Params(9);
out.xyz_new=xyz_new;
out.az=az;
out.el=el;
out.r=r;
out.omega_CO=omega_CO;
out.COM_FeCO4_new=COM_FeCO4_new;
out.A4Params=A4Params;
out.A4model=A4model;
%out.R4Params=R4Params;
%out.fittedATrajectory=fittedATrajectory;
%out.Ag=Aguess;
%out.A0g=A0guess;
%out.vAg=vAguess;

%%
if plotflag
    colo =[ 0    0.4470    0.7410
        0.8500    0.3250    0.0980
        0.7561    0.1882    0.1882
        0.4940    0.1840    0.5560
        0.4660    0.6740    0.1880
        0.3010    0.7450    0.9330
        0.6350    0.0780    0.1840];
    Ang=char(197);
    annotationFontSize=18;
    marksi=3;
    figure('Name','SI - Figure S3','Position',[100,100,1300,400]);
    tiledlayout(1,3,"TileSpacing","tight","Padding","tight")
    feco5colors = [repmat(colo(2,:), 1, 1);      % Brown for first row
        repmat([0.65, 0.65, 0.65], 5, 1);      % Grey for rows 2- 5
        repmat([1, 0, 0], 5, 1)];           % Red for rows 6-11

    nexttile
    hold on
    frame_xyz=squeeze(xyz(diss_atoms_id(1),:,:))';
    plot3(frame_xyz(:,1), frame_xyz(:,2), frame_xyz(:,3),'.-','MarkerSize',marksi,'Color',feco5colors(diss_atoms_id(1),:));

    frame_xyz=squeeze(xyz(diss_atoms_id(2),:,:))';
    plot3(frame_xyz(:,1), frame_xyz(:,2), frame_xyz(:,3),'.-','MarkerSize',marksi,'Color',feco5colors(diss_atoms_id(2),:));

    frame_xyz=squeeze(xyz(non_diss_atoms_id(1),:,:))';
    plot3(frame_xyz(:,1), frame_xyz(:,2), frame_xyz(:,3),'.-','MarkerSize',marksi,'Color',feco5colors(non_diss_atoms_id(1),:));

    COM4=squeeze(COM_FeCO4)';
    plot3(COM4(id_t0:tt(end),1), COM4(id_t0:tt(end),2), COM4(id_t0:tt(end),3), '.:','MarkerSize',marksi,  'LineWidth', 3,'Color',colo(1,:)); % Original points

    zlim([-8 0.8])
    ylim([-1 3])
    xlim([-1 7])
    view(100,40)
    xlabel(['X (' Ang ')'])
    ylabel(['Y (' Ang ')'])
    zlabel(['Z (' Ang ')'])
    set(gca,'FontSize',14)
    grid on
    ax=gca;

    annotation('textbox','String',"(a)",'Position',ax.Position-[0.025 0 0 0],...
        'Vert','top','FitBoxToText','on','EdgeColor','none','FontSize',annotationFontSize)


    h1 = plot(NaN, NaN,'.-','MarkerSize',8,'Color',feco5colors(diss_atoms_id(1),:));
    h2 = plot(NaN, NaN,'.-','MarkerSize',8,'Color',feco5colors(diss_atoms_id(2),:));
    h3 = plot(NaN, NaN,'.-','MarkerSize',5,  'LineWidth', 2,'Color',colo(1,:));
    h5 = plot(NaN, NaN,'.-', 'LineWidth', 1,'Color',feco5colors(non_diss_atoms_id(1),:));

    % Add the legend manually using the dummy plot handles
    legend([h1, h2,h5,h3], {'C', 'O','Fe','\sigma_4'}, 'Position',[0.0605,0.25,0.061,0.25],'NumColumns',1);


    nexttile
    hold on
    frame_xyz=squeeze(xyz_new(diss_atoms_id(1),:,:))';
    plot3(frame_xyz(:,1), frame_xyz(:,2), frame_xyz(:,3),'.-','MarkerSize',marksi,'Color',feco5colors(diss_atoms_id(1),:));

    frame_xyz=squeeze(xyz_new(diss_atoms_id(2),:,:))';
    plot3(frame_xyz(:,1), frame_xyz(:,2), frame_xyz(:,3),'.-','MarkerSize',marksi,'Color',feco5colors(diss_atoms_id(2),:));
    grid on

    plot3(COM_FeCO4_new(id_t0:tt(end),1), COM_FeCO4_new(id_t0:tt(end),2), COM_FeCO4_new(id_t0:tt(end),3), '.-','MarkerSize',marksi,  'LineWidth', 2,'Color',colo(1,:)); % Original points
    plot3(fittedR4Trajectory(id_t0:tt(end),1), fittedR4Trajectory(id_t0:tt(end),2), fittedR4Trajectory(id_t0:tt(end),3), ':',  'LineWidth', 3,'Color',colo(6,:)); % Fitted trajectory

    frame_xyz=squeeze(xyz_new(non_diss_atoms_id(1),:,:))';
    plot3(frame_xyz(:,1), frame_xyz(:,2), frame_xyz(:,3),'.-','MarkerSize',marksi,'Color',feco5colors(non_diss_atoms_id(1),:));

    zlim([-8 0.8]);
    ylim([-1 3]);
    xlim([-1 7]);
    view(100,40);
    xlabel(['X^\prime (' Ang ')'])
    ylabel(['Y^\prime (' Ang ')'])
    zlabel(['Z^\prime (' Ang ')'])
    set(gca,'FontSize',14)
    ax=gca;
    annotation('textbox','String',"(b)",'Position',ax.Position-[0.025 0 0 0],...
        'Vert','top','FitBoxToText','on','EdgeColor','none','FontSize',annotationFontSize)


    h1 = plot(NaN, NaN, '.-','MarkerSize',8,'Color',feco5colors(diss_atoms_id(1),:));
    h2 = plot(NaN, NaN,'.-','MarkerSize',8,'Color',feco5colors(diss_atoms_id(2),:));
    h3 = plot(NaN, NaN, '.-','MarkerSize',5,  'LineWidth', 2,'Color',colo(1,:));
    h4 = plot(NaN, NaN, ':', 'LineWidth', 3,'Color',colo(6,:));
    h5 = plot(NaN, NaN, '.-', 'LineWidth', 1,'Color',feco5colors(non_diss_atoms_id(1),:));

    legend([h1, h2,h5,h3,h4], {'C', 'O','Fe','\sigma_4^{DART}','r_4 fit'}, 'Position',[0.405,0.25,0.081,0.35],'NumColumns',1);

    nexttile
    plot(tt(2:end)-mean(diff(tt)/2),diff(unwrap(az(diss_atoms_id(1),:))),'LineWidth',2); hold on
    plot(tt(2:end)-mean(diff(tt)/2),diff(unwrap(az(diss_atoms_id(2),:))),':','LineWidth',2)
    yline(omega_CO ,'-','LineWidth',3,'Color',[ 0 0 0])
    xlabel(['Delay (fs)'])
    ylabel(['d\theta/dt (rad/fs)'])
    set(gca,'FontSize',14)
    legend('d\theta_C/dt','d\theta_O/dt','\omega_{CO} est.')
    ax=gca;
    annotation('textbox','String',"(c)",'Position',ax.Position-[0.0 0 0 0],...
        'Vert','top','FitBoxToText','on','EdgeColor','none','FontSize',annotationFontSize)

end

end

function [direction_vector] = find_direction_vector(points, plotFlag)
% bestFitLine calculates the direction vector of the best-fit line for given 3D points
% Inputs:
%   points   - Nx3 array of [x, y, z] coordinates
%   plotFlag - Optional boolean flag (true/false) to plot the results
% Outputs:
%   direction_vector - Unit vector describing the direction of the best-fit line

% Subtract the mean of the points to center them
mean_points = mean(points);
centered_points = points - mean_points;

% Perform Singular Value Decomposition (SVD) on the centered points
[~, ~, V] = svd(centered_points, 'econ');

% The first column of V is the direction vector of the best-fit line
direction_vector = V(:,1);

% Check if plotting is requested
if nargin > 1 && plotFlag
    % Plot the original points
    figure;
    plot3(points(:,1), points(:,2), points(:,3), 'bo'); % Plot points in blue
    hold on;

    % Plot the mean point
    plot3(mean_points(1), mean_points(2), mean_points(3), 'ro', 'MarkerSize', 10, 'MarkerFaceColor', 'r');

    % Generate points along the best-fit line for visualization
    t = linspace(0, 10, 100); % Adjust t range based on your data scale
    line_points = mean_points + t' * direction_vector';

    % Plot the best-fit line
    plot3(line_points(:,1), line_points(:,2), line_points(:,3), 'r-', 'LineWidth', 2);

    % Formatting the plot
    xlabel('X');
    ylabel('Y');
    zlabel('Z');
    grid on;
    axis equal;
    view(3);
    hold off;
    title('The direction vector describing the points is: [%f, %f, %f]\n', direction_vector);
end
end

function [linePoints, A, A0,v] = fit3DLine(points)
% Define the points as a matrix
plotflag=0;
centeredPoints=points-mean(points);
[V, D] = eig(cov(centeredPoints));
[~, maxIndex] = max(diag(D));
principalVector = V(:, maxIndex);
if principalVector(2) < 0
    principalVector = -V(:, maxIndex);
end

A = principalVector;  % Direction vector
projections = centeredPoints * A;
minProj = min(projections);
maxProj = max(projections);

% Calculate start and end points of the best fit line segment
A0 = mean(points) + minProj * A';
lineSegmentLength = maxProj - minProj;  % Length of the line segment

% Calculate the "velocity" v
v = lineSegmentLength / (size(points,1) - 1);

% Create a time vector t from 0 to N-1
t = (0:size(points,1)-1)';

% Calculate points on the line segment for each t
linePoints = repmat(A0, size(points,1), 1) + v * (t * A');

if plotflag
    % Plot the original points and the best fit line
    figure;
    plot3(points(:,1), points(:,2), points(:,3), 'bo');
    hold on;
    plot3(linePoints(:,1), linePoints(:,2), linePoints(:,3), 'r-', 'LineWidth', 2);
    grid on;
    xlabel('X');
    ylabel('Y');
    zlabel('Z');
    legend('Data Points', 'Best Fit Line Segment');
end
end