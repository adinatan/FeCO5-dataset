function axout = Amolecule3D(varargin)
% This code is based on André Ludwig's MOLECULE3D:
%   MOLECULE3D Draw 3D molecules
%   MOLECULE3D(XYZ,LAB) draws the molecule defined by the position matrix
%   XYZ based on the labels in the cell array LAB. XYZ is a matrix with
%   three columns representing the cartesian coordinates x, y and z in
%   Ångström with one line per atom. LAB is used to adapt the color and
%   geometry of each atom. Bonds are added if the distance between two
%   atoms is closer than DBOND (for example DBOND=1.6 [Å]).
%
%   MOLECULE3D(XYZ,LAB,STYLE) allows to change the appearance of the
%   molecule. STYLE can be on of the strings 'ballstick', 'licorice',
%   'large', or 'superlarge'. Just try it out!
%
%   MOLECULE3D(AX,...) plots into AX as the main axes, instead of GCA.
%
%   AX = MOLECULE3D(...) returns the handle of the axis.
%
%   Check out the examples in example_molecule3D.m!
%
%   Version: 1.2
%   Author:  André Ludwig (aludwig@phys.ethz.ch)
%   André (2025). molecule3D (https://www.mathworks.com/matlabcentral/fileexchange/55231-molecule3d), MATLAB Central File Exchange. Retrieved March 31, 2025. 
%
%   Version 1.3
%   Adi Natan (natan@stanford.edu)
%   added more atoms types and colors, modified parameters.

% geometry settings
RC = 0.15; % radiius of bonds
DBOND = 2.5; % maximal distance of atoms forming bond

% resolution of spheres and cylinders
NS = 50; % spheres, more looks smoother
NB = 50; % more looks smoother
% check input arguments
narginchk(2,inf);
if numel(varargin{1}) == 1 && ishghandle(varargin{1}(1)) && ...
        isequal(lower(char(get(varargin{1}(1),'type'))),'axes')
    ax = varargin{1};
    offs = 1;
else
    ax = [];
    offs = 0;
end
xyz = varargin{1+offs};
Na = size(xyz,1); % number of atoms in molecule
lab = varargin{2+offs};
if ~iscellstr(lab)
    error('Input LAB has to be a cell string')
end
lab = lab(:); % convert to column vector
if nargin - offs < 3
    style = 'ballstick'; % set default style to radi/stick
else
    style = varargin{3+offs};
end
if ~any(strcmp(style,{'ballstick','licorice','large','superlarge','small','tiny'}))
    warning('Style "%s" not found.',style)
    style = 'ballstick'; % fallback
end
if size(xyz,2) ~= 3 || Na < 1
    error('First argument should be N times 3 matrix.')
end
if numel(lab) ~= Na
    error('Number of labels does not match number of columns.')
end
% prepare axis
ax = newplot(ax);
axes(ax);
set(ax,'Visible','off','DataAspectRatio',[1 1 1]) % fix aspect ratio
light('Position',[1 1 2]); % add some light
% all combinations of atom pairs
pairs = nchoosek(1:Na,2);
% all interatomic distances
ds = sqrt(sum((xyz(pairs(:,1),:) - xyz(pairs(:,2),:)).^2,2));
% find bonds based on distances of atoms
ks = find(ds < DBOND & ~(strcmp(lab(pairs(:,1)),'H') & ...
    strcmp(lab(pairs(:,2)),'H')))';
% draw sphere with adapted radiius for each element / line in xyz
for k = 1:size(xyz,1)
    thiscol = 0.9*col(lab{k});  % change here for less light


    switch style
        case 'ballstick'
            thisr = radi(lab{k});
        case 'licorice'
            thisr = RC;
        case 'large'
            thisr = 1.5*radi(lab{k});
        case 'superlarge'
            thisr = 3*radi(lab{k});
     case 'small'
            thisr = 0.75*radi(lab{k});
         case 'tiny'
             thisr = 0.5*radi(lab{k});
      
    end

    % basic sphere
    [sx,sy,sz] = sphere(NS);

    % draw sphere
    h=surface('XData',xyz(k,1) + thisr*sx,'YData',xyz(k,2) + thisr*sy, ...
        'ZData',xyz(k,3) + thisr*sz,'FaceColor',thiscol, 'EdgeColor','none');
    %,'FaceLighting','gouraud', 'AmbientStrength', 0.25)
   
h.FaceLighting = 'gouraud';

    material metal %shiny % dull %metal
end
% draw cylinders for each bond
for k = ks % draw sticks for all bounds
    r1 = xyz(pairs(k,1),:); % coordinates atom 1
    r2 = xyz(pairs(k,2),:); % coordinates atom 2

    % bond angles in spherical coordinates
    v = (r2-r1)/norm(r2-r1);
    phi = atan2d(v(2),v(1));
    theta = -asind(v(3));

    % bond distance minus sphere radiii
    bd = ds(k) - radi(lab{pairs(k,1)}) - radi(lab{pairs(k,2)});
    cyl2 = radi(lab{pairs(k,1)}) + bd/2; % length half bond cylinder
    cyl1 = ds(k); % length full bond cylinder

    % prototype cylinders for bond
    [z,y,x] = cylinder(RC,NB); % full bond cylinder
    x(2,:) = x(2,:) * cyl1; % adjust length
    [z2,y2,x2] = cylinder(RC*1.01,NB); % half bond cylinder, thicker
    x2(2,:) = x2(2,:) * cyl2; % adjust length

    % rotate cylinders to match bond vector v
    for kk = 1:numel(x)
        vr = [x(kk); y(kk); z(kk);];
        vr = rotz(phi)*roty(theta)*vr;
        x(kk) = vr(1);
        y(kk) = vr(2);
        z(kk) = vr(3);

        vr = [x2(kk); y2(kk); z2(kk);];
        vr = rotz(phi)*roty(theta)*vr;
        x2(kk) = vr(1);
        y2(kk) = vr(2);
        z2(kk) = vr(3);
    end

    % get colors of both atoms
    thiscol1 = col(lab{pairs(k,2)});
    thiscol2 = col(lab{pairs(k,1)});

    % full bond color 1
    surface('XData',r1(1) + x,'YData',r1(2) + y,...
        'ZData',r1(3) + z,'FaceColor',thiscol1,...
        'EdgeColor','none','FaceLighting','gouraud')

    % half bond color 2
    surface('XData',r1(1) + x2,'YData',r1(2) + y2,...
        'ZData',r1(3) + z2,'FaceColor',thiscol2,...
        'EdgeColor','none','FaceLighting','gouraud')
end
if nargout > 0
    axout = ax;
end
end

%---------------------------------------------
% element specific CPK colors
function rgb = col(name)
T={ 'H'	        1.0000    1.0000    1.0000			1
    'D'	        1.0000    1.0000    0.7529			1
    'H-2'       1.0000    1.0000    0.7529			1
    'T'	        1.0000    1.0000    0.6275			1
    'H-3'	    1.0000    1.0000    0.6275			1
    'He'	    0.8510    1.0000    1.0000			2
    'Li'	    0.8000    0.5020    1.0000			3
    'Be'	    0.7608    1.0000         0			4
    'B'	        1.0000    0.7098    0.7098			5
    'C'	        0.5647    0.5647    0.5647			6
    'C-13'	    0.3137    0.3137    0.3137			6
    'C-14'	    0.2510    0.2510    0.2510			6
    'N'	        0.1882    0.3137    0.9725			7
    'N-15'	    0.0627    0.3137    0.3137			7
    'O'	        1.0000    0.0510    0.0510			8
    'F'	        0.5647    0.8784    0.3137			9
    'Ne'	    0.7020    0.8902    0.9608			10
    'Na'	    0.6706    0.3608    0.9490			11
    'Mg'	    0.5412    1.0000         0			12
    'Al'	    0.7490    0.6510    0.6510			13
    'Si'	    0.9412    0.7843    0.6275			14
    'P'	        1.0000    0.5020         0			15
    'S'	        1.0000    1.0000    0.1882			16
    'Cl'	    0.1216    0.9412    0.1216			17
    'Ar'	    0.5020    0.8196    0.8902			18
    'K'	        0.5608    0.2510    0.8314			19
    'Ca'	    0.2392    1.0000         0			20
    'Sc'	    0.9020    0.9020    0.9020			21
    'Ti'	    0.7490    0.7608    0.7804			22
    'V'	        0.6510    0.6510    0.6706			23
    'Cr'	    0.5412    0.6000    0.7804			24
    'Mn'	    0.6118    0.4784    0.7804			25
    'Fe'	    0.8784    0.4000    0.2000			26
    'Co'	    0.9412    0.5647    0.6275			27
    'Ni'	    0.3137    0.8157    0.3137			28
    'Cu'	    0.7843    0.5020    0.2000			29
    'Zn'	    0.4902    0.5020    0.6902			30
    'Ga'	    0.7608    0.5608    0.5608			31
    'Ge'	    0.4000    0.5608    0.5608			32
    'As'	    0.7412    0.5020    0.8902			33
    'Se'	    1.0000    0.6314         0			34
    'Br'	    0.6510    0.1608    0.1608			35
    'Kr'	    0.3608    0.7216    0.8196			36
    'Rb'	    0.4392    0.1804    0.6902			37
    'Sr'	         0    1.0000         0			38
    'Y'	        0.5804    1.0000    1.0000			39
    'Zr'	    0.5804    0.8784    0.8784			40
    'Nb'	    0.4510    0.7608    0.7882			41
    'Mo'	    0.3294    0.7098    0.7098			42
    'Tc'	    0.2314    0.6196    0.6196			43
    'Ru'	    0.1412    0.5608    0.5608			44
    'Rh'	    0.0392    0.4902    0.5490			45
    'Pd'	         0    0.4118    0.5216			46
    'Ag'	    0.7529    0.7529    0.7529			47
    'Cd'	    1.0000    0.8510    0.5608			48
    'In'	    0.6510    0.4588    0.4510			49
    'Sn'	    0.4000    0.5020    0.5020			50
    'Sb'	    0.6196    0.3882    0.7098			51
    'Te'	    0.8314    0.4784         0			52
    'I'	        0.5804         0    0.5804			53
    'Xe'	    0.2588    0.6196    0.6902			54
    'Cs'	    0.3412    0.0902    0.5608			55
    'Ba'	         0    0.7882         0			56
    'La'	    0.4392    0.8314    1.0000			57
    'Ce'	    1.0000    1.0000    0.7804			58
    'Pr'	    0.8510    1.0000    0.7804			59
    'Nd'	    0.7804    1.0000    0.7804			60
    'Pm'	    0.6392    1.0000    0.7804			61
    'Sm'	    0.5608    1.0000    0.7804			62
    'Eu'	    0.3804    1.0000    0.7804			63
    'Gd'	    0.2706    1.0000    0.7804			64
    'Tb'	    0.1882    1.0000    0.7804			65
    'Dy'	    0.1216    1.0000    0.7804			66
    'Ho'	         0    1.0000    0.6118			67
    'Er'	         0    0.9020    0.4588			68
    'Tm'	         0    0.8314    0.3216			69
    'Yb'	         0    0.7490    0.2196			70
    'Lu'	         0    0.6706    0.1412			71
    'Hf'	    0.3020    0.7608    1.0000			72
    'Ta'	    0.3020    0.6510    1.0000			73
    'W'	        0.1294    0.5804    0.8392			74
    'Re'	    0.1490    0.4902    0.6706			75
    'Os'	    0.1490    0.4000    0.5882			76
    'Ir'	    0.0902    0.3294    0.5294			77
    'Pt'	    0.8157    0.8157    0.8784			78
    'Au'	    1.0000    0.8196    0.1373			79
    'Hg'	    0.7216    0.7216    0.8157			80
    'Tl'	    0.6510    0.3294    0.3020			81
    'Pb'	    0.3412    0.3490    0.3804			82
    'Bi'	    0.6196    0.3098    0.7098			83
    'Po'	    0.6706    0.3608         0			84
    'At'	    0.4588    0.3098    0.2706			85
    'Rn'	    0.2588    0.5098    0.5882			86
    'Fr'	    0.2588         0    0.4000			87
    'Ra'	         0    0.4902         0			88
    'Ac'	    0.4392    0.6706    0.9804			89
    'Th'	         0    0.7294    1.0000			90
    'Pa'	         0    0.6314    1.0000			91
    'U'	            0    0.5608    1.0000			92
    'Np'	         0    0.5020    1.0000			93
    'Pu'	         0    0.4196    1.0000			94
    'Am'	    0.3294    0.3608    0.9490			95
    'Cm'	    0.4706    0.3608    0.8902			96
    'Bk'	    0.5412    0.3098    0.8902			97
    'Cf'	    0.6314    0.2118    0.8314			98
    'Es'	    0.7020    0.1216    0.8314			99
    'Fm'	    0.7020    0.1216    0.7294			100
    'Md'	    0.7020    0.0510    0.6510			101
    'No'	    0.7412    0.0510    0.5294			102
    'Lr'	    0.7804         0    0.4000			103
    'Rf'	    0.8000         0    0.3490			104
    'Db'	    0.8196         0    0.3098			105
    'Sg'	    0.8510         0    0.2706			106
    'Bh'	    0.8784         0    0.2196			107
    'Hs'	    0.9020         0    0.1804			108
    'Mt'	    0.9216         0    0.1490			109};
 
rgb=[T{strcmp(T(:,1),name),2:4}];
z=[T{strcmp(T(:,1),name),5}];
end
%---------------------------------------------
% element specific radiii
function r = radi(s)
switch s
    case  'H', r = 0.3;
    case  'C', r = 0.5;
    case  'O', r = 0.5;
    case  'N', r = 0.5;
    case  'Ir', r = 0.7;
    case  'Pt', r = 0.7;

    otherwise, r = 0.5;
end
end
