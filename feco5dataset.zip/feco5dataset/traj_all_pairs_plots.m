% this script show the simulated pair density dynamics, averaging all
% trajectories used in the study.

load sim_all_traj_avg.mat

% parse data from file
pairs=sim_all_traj_avg.pairs; % a 3D array (R x t x pair type)
t=sim_all_traj_avg.t;
Rab_grid=sim_all_traj_avg.Rab_grid;
u_pairs_str=sim_all_traj_avg.u_pairs_str; % the 5 types of pairs

%% Figures 2a:
% The simulated pair density difference ∆PD for photoexcited Fe(CO)5 obtained
% from averaging 103 trajectories, and derived by subtracting the steady state
% pair density from the time-dependent density. The motion initiates within
% the Fe-C bond (~1.8 A), however, it is also observed across most pairs
% due to the spectator effect.

set(figure,'Name','Fig 2a data')
EF=0.08 ; % est. excitation fraction
Ang=char(197); fontsize=12;
yl1=0.7; yl2=9.5; xl2=640;

tl=tiledlayout(1, 5,"TileSpacing","none")

nexttile
area(Rab_grid,squeeze(pairs(:,1,:)))
xlim([yl1 yl2])
ax=gca;
ax.XAxisLocation = 'top';
legend( join(u_pairs_str, "-") ,"FontSize",8,"Location","north")
xlabel(['R (' Ang ')'])
ylabel('Density (e^2)');
set(gca,'FontSize',fontsize);
 camroll(90)

Delta_pairs= sum(pairs,3)-sum(pairs(:,1,:),3) ;
nexttile([1 4])
imagesc(t,Rab_grid, EF*Delta_pairs);
set(gca,'Ydir','normal','YTickLabel','');
 
ylim([yl1 yl2]);
xlim([0  xl2]);
%ylabel(tl,['R (' Ang ')'])
xlabel('Delay (fs)');
title(['\Delta All pairs'] )
set(gca,'FontSize',10)
colormap(bluewhitered)

cb0= colorbar;
cb0.LineWidth=1;
cb0.FontSize=10;
colorTitleHandle = get(cb0,'Title');
titleString = ['e^2'];
set(colorTitleHandle ,'String',titleString);



%% Figure S5:
%  The time-dependent pair density, averaged across all trajectories,
% is calculated following extrapolation up to the duration of the longest-lived
% trajectory (640 fs). The plot shows the contribution of the various types
% of atomic pairs

set(figure,'Name','SI - Fig S5 data','Position',[100 100 1000 600]) ;
tl=tiledlayout(2,3);
yl1=0.7 ; yl2=9.5;
xl2=640;
Ang=char(197);

nexttile

imagesc(t,Rab_grid,1e-2*sum(pairs,3));
set(gca,'Ydir','normal');
ylim([yl1 yl2]);
xlim([0  xl2]);
ylabel(['R (' Ang ')'])
xlabel('Delay (fs)');
title(['All pairs'] )
set(gca,'FontSize',10)
caxis([0 5])
colormap("parula")

cb0= colorbar;
cb0.LineWidth=1;
cb0.FontSize=10;
colorTitleHandle = get(cb0,'Title');
titleString = ['10^2e^2'];
set(colorTitleHandle ,'String',titleString);

for k=1:size(pairs,3)

    nexttile
    imagesc(t,Rab_grid,1e-2*pairs(:,:,k) ); colorbar
    set(gca,'Ydir','normal');
    ylim([yl1 yl2]);
    xlim([0  xl2])

    ylabel(['R (' Ang ')'])
    xlabel('Delay (fs)');
    title(['' reshape(char(u_pairs_str(k,:)),1,[])] )
    caxis([0 5])
    colormap("parula")

    cb1=colorbar;
    cb1.LineWidth=1;
    cb1.FontSize=10;
    colorTitleHandle = get(cb1,'Title');
    titleString = ['10^2e^2'];
    set(colorTitleHandle ,'String',titleString);
end